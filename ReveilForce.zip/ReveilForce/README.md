# RéveilForcé ⏰

Un réveil Android conçu pour une seule chose : **te forcer à te réveiller vraiment**,
même si empiler des alarmes classiques ne marche pas sur toi.

## Pourquoi cette appli

Une alarme normale, tu l'éteins d'un geste à moitié endormi et tu te rendors.
RéveilForcé t'oblige à résoudre une vraie séquence de défis avant de couper le son :
calculs, secousses du téléphone, recopie d'une phrase exacte... impossible de le faire
sans être réellement réveillé et actif.

## Niveau de "chiant" (5 crans, réglables)

| Niveau | Ce qu'il faut faire pour couper l'alarme | Snooze |
|---|---|---|
| 1 — Facile | Maintenir un bouton appuyé 3 secondes | Illimité |
| 2 — Modéré | Résoudre 3 calculs simples | 1 fois |
| 3 — Difficile | Secouer le téléphone + 3 calculs | Aucun |
| 4 — Cauchemar | Secousses fortes + 4 calculs corsés + recopier une phrase exacte | Aucun |
| 5 — Extrême | Secousses intenses + 6 calculs + 2 phrases à recopier, volume au max immédiatement | Aucun |

Le niveau par défaut se règle sur l'écran principal et s'applique à chaque nouvelle
alarme ; chaque alarme peut aussi avoir son propre niveau.

## Ce qui rend le réveil difficile à ignorer

- **Son sur le flux ALARME** (`STREAM_ALARM`) : il sonne même si le téléphone est en
  mode silencieux/vibreur, et le volume peut monter progressivement (ou directement
  au max en niveau Extrême).
- **Écran plein écran par-dessus le verrouillage** via `AlarmManager.setAlarmClock()`,
  l'API réservée aux vraies apps de réveil — elle sonne à l'heure exacte même en veille
  profonde (Doze), sans permission spéciale à activer.
- **Bouton retour neutralisé** : impossible de fermer l'écran d'alarme avec "Retour".
- **Anti-fuite par le bouton Accueil** : si tu quittes l'écran sans avoir fini tes
  défis, il se relance automatiquement au premier plan.
- **Vibration continue** en plus du son.
- Se **relance après un redémarrage** du téléphone (toutes les alarmes actives sont
  reprogrammées automatiquement).

### Limite honnête

Android ne permet à aucune application, même une app de réveil, de bloquer à 100 %
les boutons Accueil/Récents ou un force-arrêt depuis les réglages système — il n'existe
pas d'API publique pour ça sans droits d'administrateur d'appareil. Le mécanisme
"anti-fuite" ici (relance immédiate au premier plan) est la technique standard utilisée
par les applications de réveil sérieuses du Play Store, et elle est déjà nettement plus
difficile à contourner à moitié endormi qu'une alarme classique.

## Compiler l'APK

### Option 1 — GitHub Actions (recommandé, aucune installation)

1. Crée un dépôt GitHub et pousse ce dossier tel quel (avec `.github/workflows/build-apk.yml`).
2. Va dans l'onglet **Actions** du dépôt : le build se lance automatiquement sur le
   push (ou lance-le manuellement via "Run workflow").
3. Une fois le job terminé, télécharge l'artefact **ReveilForce-debug-apk** : il
   contient le fichier `.apk` à installer sur ton téléphone.

### Option 2 — En local avec Android Studio

1. Ouvre le dossier `ReveilForce` dans Android Studio.
2. Laisse Gradle synchroniser.
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

## Installer l'APK sur le téléphone

1. Transfère le `.apk` sur le téléphone (câble, Drive, etc.).
2. Autorise "Installer des applications inconnues" pour l'app utilisée pour ouvrir
   le fichier (Réglages > Applications > Accès spécial).
3. Ouvre le fichier `.apk` et installe.

## À faire après l'installation, pour que ça marche vraiment

- **Autoriser les notifications** (demandé au premier lancement).
- **Désactiver l'optimisation de batterie** pour RéveilForcé (Réglages > Batterie >
  RéveilForcé > Non optimisée), sinon le système peut tuer le service qui joue le son.
- Sur certains téléphones (Xiaomi/MIUI, Huawei, Oppo, Samsung en mode économie
  agressive...), il faut aussi activer manuellement "Démarrage automatique" /
  "Autoriser en arrière-plan" pour l'app dans les réglages constructeur.
- Vérifier que le **volume du flux Alarme** (pas le volume média) n'est pas coupé
  dans les réglages sonores du téléphone.

## Structure du projet

Projet Android natif Kotlin classique (même schéma que `StepStreak`) :
- `AlarmScheduler` / `AlarmReceiver` : planification et déclenchement à l'heure exacte
- `AlarmService` : service au premier plan qui fait vraiment sonner (son + volume + vibration)
- `AlarmActivity` : écran plein écran avec la séquence de défis
- `ChallengeManager` / `ShakeDetector` : génération des calculs/phrases et détection des secousses
- `AlarmPrefs` : stockage local des alarmes (SharedPreferences, sans dépendance externe)
- `MainActivity` : écran principal (liste des alarmes, réglage du niveau par défaut, bouton de test)
