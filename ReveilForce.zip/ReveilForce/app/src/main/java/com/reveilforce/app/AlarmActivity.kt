package com.reveilforce.app

import android.app.KeyguardManager
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Écran plein écran affiché par-dessus le verrouillage quand l'alarme sonne.
 * Impossible à fermer avec le bouton retour ; si l'utilisateur appuie sur
 * "Accueil", l'activité se relance immédiatement au premier plan tant que
 * la séquence de défis n'est pas terminée (technique standard des apps de
 * réveil "anti-dismiss" — ce n'est toutefois pas un blocage garanti à 100%,
 * Android ne le permet pas sans droits d'administration spéciaux).
 */
class AlarmActivity : AppCompatActivity() {

    private var alarm: Alarm? = null
    private lateinit var level: AnnoyanceLevel
    private var challengeIndex = 0
    private var challengeCompleted = false
    private var snoozeUsedThisRing = false

    private var shakeDetector: ShakeDetector? = null
    private var shakeCount = 0
    private var shakeTarget = 0

    private var currentMathAnswer = 0
    private var currentSentence = ""

    private val holdHandler = Handler(Looper.getMainLooper())
    private var holdProgress = 0
    private var holdRunnable: Runnable? = null

    // Vues
    private lateinit var tvAlarmTime: TextView
    private lateinit var tvAlarmLabel: TextView
    private lateinit var tvChallengeProgress: TextView
    private lateinit var btnSnooze: Button
    private lateinit var tvVolumeWarning: TextView

    private lateinit var holdLayout: LinearLayout
    private lateinit var btnHold: Button
    private lateinit var holdProgressBar: ProgressBar

    private lateinit var mathLayout: LinearLayout
    private lateinit var tvMathProblem: TextView
    private lateinit var etMathAnswer: EditText
    private lateinit var btnMathSubmit: Button
    private lateinit var tvMathFeedback: TextView

    private lateinit var shakeLayout: LinearLayout
    private lateinit var tvShakeCount: TextView
    private lateinit var shakeProgressBar: ProgressBar

    private lateinit var typeLayout: LinearLayout
    private lateinit var tvSentenceToType: TextView
    private lateinit var etTypedSentence: EditText
    private lateinit var btnTypeSubmit: Button
    private lateinit var tvTypeFeedback: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowOnLockScreenFlags()
        setContentView(R.layout.activity_alarm)
        bindViews()

        val alarmId = intent.getIntExtra(AlarmScheduler.EXTRA_ALARM_ID, -1)
        alarm = if (alarmId != -1) AlarmPrefs.getAlarmById(this, alarmId) else null
        level = AnnoyanceLevel.fromOrdinal(alarm?.level ?: 1)

        tvAlarmTime.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(java.util.Date())
        tvAlarmLabel.text = alarm?.label?.ifBlank { "Réveil" } ?: "Réveil"

        setupSnoozeButton()
        setupHoldChallenge()
        setupMathChallenge()
        setupShakeChallenge()
        setupTypeChallenge()

        showChallenge(0)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Le bouton retour ne fait rien : impossible de fuir l'alarme comme ça.
            }
        })
    }

    private fun setShowOnLockScreenFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            km.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun bindViews() {
        tvAlarmTime = findViewById(R.id.tvAlarmTime)
        tvAlarmLabel = findViewById(R.id.tvAlarmLabel)
        tvChallengeProgress = findViewById(R.id.tvChallengeProgress)
        btnSnooze = findViewById(R.id.btnSnooze)
        tvVolumeWarning = findViewById(R.id.tvVolumeWarning)

        holdLayout = findViewById(R.id.holdChallengeLayout)
        btnHold = findViewById(R.id.btnHold)
        holdProgressBar = findViewById(R.id.holdProgressBar)

        mathLayout = findViewById(R.id.mathChallengeLayout)
        tvMathProblem = findViewById(R.id.tvMathProblem)
        etMathAnswer = findViewById(R.id.etMathAnswer)
        btnMathSubmit = findViewById(R.id.btnMathSubmit)
        tvMathFeedback = findViewById(R.id.tvMathFeedback)

        shakeLayout = findViewById(R.id.shakeChallengeLayout)
        tvShakeCount = findViewById(R.id.tvShakeCount)
        shakeProgressBar = findViewById(R.id.shakeProgressBar)

        typeLayout = findViewById(R.id.typeChallengeLayout)
        tvSentenceToType = findViewById(R.id.tvSentenceToType)
        etTypedSentence = findViewById(R.id.etTypedSentence)
        btnTypeSubmit = findViewById(R.id.btnTypeSubmit)
        tvTypeFeedback = findViewById(R.id.tvTypeFeedback)
    }

    // --- Gestion de la séquence de défis --------------------------------------------------

    private fun showChallenge(index: Int) {
        holdLayout.visibility = android.view.View.GONE
        mathLayout.visibility = android.view.View.GONE
        shakeLayout.visibility = android.view.View.GONE
        typeLayout.visibility = android.view.View.GONE
        shakeDetector?.stop()

        if (index >= level.challenges.size) {
            onAllChallengesCompleted()
            return
        }
        challengeIndex = index
        tvChallengeProgress.text = "Défi ${index + 1} / ${level.challenges.size}"

        when (level.challenges[index]) {
            ChallengeType.HOLD_BUTTON -> {
                holdLayout.visibility = android.view.View.VISIBLE
                holdProgress = 0
                holdProgressBar.progress = 0
            }
            ChallengeType.MATH -> {
                mathLayout.visibility = android.view.View.VISIBLE
                val problem = ChallengeManager.randomMathProblem(level)
                currentMathAnswer = problem.answer
                tvMathProblem.text = problem.question
                etMathAnswer.setText("")
                tvMathFeedback.text = ""
            }
            ChallengeType.SHAKE -> {
                shakeLayout.visibility = android.view.View.VISIBLE
                shakeCount = 0
                shakeTarget = ChallengeManager.shakeTarget(level)
                shakeProgressBar.max = shakeTarget
                shakeProgressBar.progress = 0
                tvShakeCount.text = "0 / $shakeTarget"
                shakeDetector = ShakeDetector(this) { onShakeDetected() }
                shakeDetector?.start()
            }
            ChallengeType.TYPE_SENTENCE -> {
                typeLayout.visibility = android.view.View.VISIBLE
                currentSentence = ChallengeManager.randomSentence()
                tvSentenceToType.text = currentSentence
                etTypedSentence.setText("")
                tvTypeFeedback.text = ""
            }
        }
    }

    private fun onAllChallengesCompleted() {
        challengeCompleted = true
        shakeDetector?.stop()
        playSuccessChime()
        AlarmService.stopRinging(this)
        finish()
    }

    private fun playSuccessChime() {
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                    .build()
            )
            val afd = resources.openRawResourceFd(R.raw.success_chime)
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            mp.setOnCompletionListener { it.release() }
            mp.prepare()
            mp.start()
        } catch (e: Exception) {
            // best-effort
        }
    }

    private fun playErrorBuzz() {
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                    .build()
            )
            val afd = resources.openRawResourceFd(R.raw.error_buzz)
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            mp.setOnCompletionListener { it.release() }
            mp.prepare()
            mp.start()
        } catch (e: Exception) {
            // best-effort
        }
    }

    // --- Défi "maintenir" ------------------------------------------------------------------

    private fun setupHoldChallenge() {
        btnHold.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startHoldProgress()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    cancelHoldProgress()
                    true
                }
                else -> false
            }
        }
    }

    private fun startHoldProgress() {
        holdRunnable = object : Runnable {
            override fun run() {
                holdProgress += 4
                holdProgressBar.progress = holdProgress.coerceAtMost(100)
                if (holdProgress >= 100) {
                    showChallenge(challengeIndex + 1)
                } else {
                    holdHandler.postDelayed(this, 120)
                }
            }
        }
        holdHandler.post(holdRunnable!!)
    }

    private fun cancelHoldProgress() {
        holdRunnable?.let { holdHandler.removeCallbacks(it) }
        holdProgress = 0
        holdProgressBar.progress = 0
    }

    // --- Défi mathématique -------------------------------------------------------------------

    private fun setupMathChallenge() {
        btnMathSubmit.setOnClickListener {
            val input = etMathAnswer.text.toString().trim()
            val value = input.toIntOrNull()
            if (value != null && value == currentMathAnswer) {
                showChallenge(challengeIndex + 1)
            } else {
                tvMathFeedback.text = "Faux, réessaie."
                playErrorBuzz()
                val problem = ChallengeManager.randomMathProblem(level)
                currentMathAnswer = problem.answer
                tvMathProblem.text = problem.question
                etMathAnswer.setText("")
            }
        }
    }

    // --- Défi "secouer" ------------------------------------------------------------------------

    private fun onShakeDetected() {
        shakeCount++
        runOnUiThread {
            shakeProgressBar.progress = shakeCount.coerceAtMost(shakeTarget)
            tvShakeCount.text = "${shakeCount.coerceAtMost(shakeTarget)} / $shakeTarget"
            if (shakeCount >= shakeTarget) {
                showChallenge(challengeIndex + 1)
            }
        }
    }

    // --- Défi "recopier la phrase" --------------------------------------------------------------

    private fun setupTypeChallenge() {
        btnTypeSubmit.setOnClickListener {
            val typed = etTypedSentence.text.toString().trim()
            if (typed.equals(currentSentence.trim(), ignoreCase = false)) {
                showChallenge(challengeIndex + 1)
            } else {
                tvTypeFeedback.text = "Pas exact, recopie bien la phrase entière."
                playErrorBuzz()
            }
        }
    }

    // --- Snooze --------------------------------------------------------------------------------

    private fun setupSnoozeButton() {
        val a = alarm
        val canSnooze = level.snoozeAllowed && a != null && a.lastSnoozeDate != todayString()
        btnSnooze.visibility = if (canSnooze) android.view.View.VISIBLE else android.view.View.GONE
        btnSnooze.setOnClickListener {
            if (snoozeUsedThisRing) return@setOnClickListener
            snoozeUsedThisRing = true
            a?.let {
                it.lastSnoozeDate = todayString()
                AlarmPrefs.updateAlarm(this, it)
                scheduleSnoozeAlarm(it)
            }
            AlarmService.stopRinging(this)
            finish()
        }
    }

    private fun scheduleSnoozeAlarm(a: Alarm) {
        val am = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
        val triggerAt = System.currentTimeMillis() + 5 * 60 * 1000L
        val intent = android.content.Intent(this, AlarmReceiver::class.java).apply {
            putExtra(AlarmScheduler.EXTRA_ALARM_ID, a.id)
        }
        val pi = android.app.PendingIntent.getBroadcast(
            this, a.id + 500000, intent,
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        try {
            am.setAlarmClock(android.app.AlarmManager.AlarmClockInfo(triggerAt, pi), pi)
        } catch (e: Exception) {
            // best-effort
        }
    }

    private fun todayString(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(java.util.Date())

    // --- Anti-fuite : si l'utilisateur appuie sur Accueil, on se relance au premier plan --------

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (!challengeCompleted) {
            val i = android.content.Intent(this, AlarmActivity::class.java).apply {
                putExtra(AlarmScheduler.EXTRA_ALARM_ID, alarm?.id ?: -1)
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or
                        android.content.Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                        android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(i)
        }
    }

    override fun onDestroy() {
        shakeDetector?.stop()
        holdRunnable?.let { holdHandler.removeCallbacks(it) }
        super.onDestroy()
    }
}
