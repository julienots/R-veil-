package com.reveilforce.app

import android.content.Context

/**
 * Stockage local simple (SharedPreferences) de la liste des alarmes
 * et des réglages globaux. Sérialisation maison, pas de dépendance JSON.
 */
object AlarmPrefs {
    private const val PREFS = "reveil_force_prefs"
    private const val KEY_ALARMS = "alarms"
    private const val KEY_NEXT_ID = "next_id"
    private const val KEY_DEFAULT_LEVEL = "default_level"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getAlarms(context: Context): List<Alarm> {
        val raw = prefs(context).getString(KEY_ALARMS, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.split("\n").mapNotNull { Alarm.deserialize(it) }
    }

    fun saveAlarms(context: Context, alarms: List<Alarm>) {
        val raw = alarms.joinToString("\n") { it.serialize() }
        prefs(context).edit().putString(KEY_ALARMS, raw).apply()
    }

    fun addAlarm(context: Context, alarm: Alarm): Alarm {
        val list = getAlarms(context).toMutableList()
        list.add(alarm)
        saveAlarms(context, list)
        return alarm
    }

    fun updateAlarm(context: Context, alarm: Alarm) {
        val list = getAlarms(context).toMutableList()
        val idx = list.indexOfFirst { it.id == alarm.id }
        if (idx >= 0) {
            list[idx] = alarm
            saveAlarms(context, list)
        }
    }

    fun deleteAlarm(context: Context, id: Int) {
        val list = getAlarms(context).filter { it.id != id }
        saveAlarms(context, list)
    }

    fun getAlarmById(context: Context, id: Int): Alarm? {
        if (id == TEST_ALARM_ID) return transientTestAlarm
        return getAlarms(context).firstOrNull { it.id == id }
    }

    /** Alarme temporaire utilisée uniquement par le bouton "Tester le réveil maintenant". */
    const val TEST_ALARM_ID = -1
    var transientTestAlarm: Alarm? = null

    fun nextId(context: Context): Int {
        val p = prefs(context)
        val id = p.getInt(KEY_NEXT_ID, 1)
        p.edit().putInt(KEY_NEXT_ID, id + 1).apply()
        return id
    }

    fun defaultLevel(context: Context): Int = prefs(context).getInt(KEY_DEFAULT_LEVEL, 1)

    fun setDefaultLevel(context: Context, level: Int) {
        prefs(context).edit().putInt(KEY_DEFAULT_LEVEL, level).apply()
    }
}
