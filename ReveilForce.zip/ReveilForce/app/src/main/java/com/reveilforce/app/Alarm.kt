package com.reveilforce.app

/**
 * Représente une alarme configurée par l'utilisateur.
 * [days] contient les jours de répétition (Calendar.SUNDAY=1 .. Calendar.SATURDAY=7).
 * Si [days] est vide, l'alarme ne sonne qu'une seule fois puis se désactive.
 * [level] va de 0 (Facile) à 4 (Extrême), voir AnnoyanceLevel.
 */
data class Alarm(
    val id: Int,
    var hour: Int,
    var minute: Int,
    var label: String,
    var days: Set<Int>,
    var enabled: Boolean,
    var level: Int,
    var lastSnoozeDate: String? = null // yyyy-MM-dd du dernier snooze utilisé, pour limiter à 1/jour
) {
    fun serialize(): String {
        val daysStr = days.joinToString(",")
        val safeLabel = label.replace("|", " ").replace(";", " ")
        return "$id;$hour;$minute;$safeLabel;$daysStr;$enabled;$level;${lastSnoozeDate ?: ""}"
    }

    companion object {
        fun deserialize(raw: String): Alarm? {
            return try {
                val parts = raw.split(";")
                val days = if (parts[4].isBlank()) emptySet() else parts[4].split(",").map { it.toInt() }.toSet()
                Alarm(
                    id = parts[0].toInt(),
                    hour = parts[1].toInt(),
                    minute = parts[2].toInt(),
                    label = parts[3],
                    days = days,
                    enabled = parts[5].toBoolean(),
                    level = parts[6].toInt(),
                    lastSnoozeDate = parts.getOrNull(7)?.takeIf { it.isNotBlank() }
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
