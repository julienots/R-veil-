package com.reveilforce.app

import android.Manifest
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.TimePicker
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private lateinit var alarmListContainer: LinearLayout
    private lateinit var tvEmptyState: TextView
    private lateinit var tvLevelName: TextView
    private lateinit var tvLevelDesc: TextView
    private lateinit var seekLevel: SeekBar

    private val dayLabels = listOf("D", "L", "M", "M", "J", "V", "S") // Calendar.SUNDAY..SATURDAY

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        NotificationHelper.ensureChannel(this)
        requestNotificationPermissionIfNeeded()

        alarmListContainer = findViewById(R.id.alarmListContainer)
        tvEmptyState = findViewById(R.id.tvEmptyState)
        tvLevelName = findViewById(R.id.tvLevelName)
        tvLevelDesc = findViewById(R.id.tvLevelDesc)
        seekLevel = findViewById(R.id.seekLevel)

        seekLevel.progress = AlarmPrefs.defaultLevel(this)
        updateLevelTexts(AlarmPrefs.defaultLevel(this))
        seekLevel.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateLevelTexts(progress)
                if (fromUser) AlarmPrefs.setDefaultLevel(this@MainActivity, progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        findViewById<View>(R.id.btnAddAlarm).setOnClickListener { showAddAlarmDialog() }
        findViewById<View>(R.id.btnTestAlarm).setOnClickListener { launchTestAlarm() }

        findViewById<View>(R.id.btnFixBattery).setOnClickListener { requestIgnoreBatteryOptimizations() }
        findViewById<View>(R.id.btnFixAutostart).setOnClickListener { openAutostartSettings() }
        findViewById<View>(R.id.btnFixFullScreen).setOnClickListener { requestFullScreenIntentPermission() }

        renderAlarmList()
    }

    override fun onResume() {
        super.onResume()
        renderAlarmList()
        updateBackgroundWarningCard()
    }

    // --- Fiabilité en arrière-plan --------------------------------------------------------
    // Le principal responsable des alarmes qui ne sonnent jamais n'est presque jamais le code
    // de planification (AlarmManager.setAlarmClock est déjà le mécanisme le plus fiable qui
    // existe), mais les restrictions ajoutées par Android/le fabricant qui tuent l'appli avant
    // que l'alarme ne se déclenche : optimisation de batterie, listes de "démarrage
    // automatique" propriétaires (Xiaomi/Huawei/Oppo/Vivo/Samsung...), et depuis Android 14 la
    // permission séparée pour les notifications plein écran.

    private fun isIgnoringBatteryOptimizations(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun canUseFullScreenIntent(): Boolean {
        if (Build.VERSION.SDK_INT < 34) return true
        val nm = getSystemService(NotificationManager::class.java)
        return nm.canUseFullScreenIntent()
    }

    private fun updateBackgroundWarningCard() {
        val card = findViewById<View>(R.id.cardBackgroundWarning)
        val tvDesc = findViewById<TextView>(R.id.tvBackgroundWarningDesc)
        val btnBattery = findViewById<View>(R.id.btnFixBattery)
        val btnAutostart = findViewById<View>(R.id.btnFixAutostart)
        val btnFullScreen = findViewById<View>(R.id.btnFixFullScreen)

        val needsBattery = !isIgnoringBatteryOptimizations()
        val needsAutostart = needsBattery && hasKnownAutostartSettings()
        val needsFullScreen = !canUseFullScreenIntent()

        btnBattery.visibility = if (needsBattery) View.VISIBLE else View.GONE
        btnAutostart.visibility = if (needsAutostart) View.VISIBLE else View.GONE
        btnFullScreen.visibility = if (needsFullScreen) View.VISIBLE else View.GONE

        card.visibility = if (needsBattery || needsFullScreen) View.VISIBLE else View.GONE
        tvDesc.text = if (needsBattery) {
            "Ton téléphone peut fermer l'appli pendant la nuit et empêcher l'alarme de sonner. Corrige ça en 10 secondes :"
        } else {
            "L'affichage plein écran du réveil par-dessus l'écran verrouillé n'est pas autorisé. Sans ça, l'alarme peut sonner sans que l'écran s'allume :"
        }
    }

    private fun requestIgnoreBatteryOptimizations() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: ActivityNotFoundException) {
                openAppDetailsSettings()
            }
        }
    }

    private fun requestFullScreenIntentPermission() {
        if (Build.VERSION.SDK_INT < 34) return
        try {
            val intent = Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            openAppDetailsSettings()
        }
    }

    private fun openAppDetailsSettings() {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (e: ActivityNotFoundException) { /* rien à faire de plus */ }
    }

    /** Écrans "démarrage automatique" propriétaires connus, par fabricant. */
    private fun autostartComponents(): List<ComponentName> {
        return listOf(
            ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"),
            ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
            ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"),
            ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"),
            ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
            ComponentName("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"),
            ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity"),
            ComponentName("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity"),
            ComponentName("com.meizu.safe", "com.meizu.safe.permission.PermissionMainActivity")
        )
    }

    private fun hasKnownAutostartSettings(): Boolean {
        return autostartComponents().any { isComponentAvailable(it) }
    }

    private fun isComponentAvailable(component: ComponentName): Boolean {
        return try {
            packageManager.getActivityInfo(component, 0) != null
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun openAutostartSettings() {
        for (component in autostartComponents()) {
            if (isComponentAvailable(component)) {
                try {
                    startActivity(Intent().apply {
                        this.component = component
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    })
                    return
                } catch (e: Exception) { /* essaie le suivant */ }
            }
        }
        openAppDetailsSettings()
    }

    private fun updateLevelTexts(progress: Int) {
        val level = AnnoyanceLevel.fromOrdinal(progress)
        tvLevelName.text = level.displayName
        tvLevelDesc.text = level.description
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100
                )
            }
        }
    }

    // --- Liste des alarmes ---------------------------------------------------------------

    private fun renderAlarmList() {
        alarmListContainer.removeAllViews()
        val alarms = AlarmPrefs.getAlarms(this).sortedWith(compareBy({ it.hour }, { it.minute }))
        tvEmptyState.visibility = if (alarms.isEmpty()) View.VISIBLE else View.GONE

        val inflater = LayoutInflater.from(this)
        for (alarm in alarms) {
            val row = inflater.inflate(R.layout.item_alarm, alarmListContainer, false)
            val tvTime = row.findViewById<TextView>(R.id.tvTime)
            val tvDays = row.findViewById<TextView>(R.id.tvDays)
            val tvLevel = row.findViewById<TextView>(R.id.tvLevel)
            val switchEnabled = row.findViewById<SwitchCompat>(R.id.switchEnabled)
            val btnDelete = row.findViewById<TextView>(R.id.btnDelete)

            tvTime.text = String.format("%02d:%02d", alarm.hour, alarm.minute)
            tvDays.text = formatDays(alarm.days)
            tvLevel.text = AnnoyanceLevel.fromOrdinal(alarm.level).displayName
            switchEnabled.isChecked = alarm.enabled

            switchEnabled.setOnCheckedChangeListener { _, isChecked ->
                alarm.enabled = isChecked
                AlarmPrefs.updateAlarm(this, alarm)
                if (isChecked) AlarmScheduler.schedule(this, alarm) else AlarmScheduler.cancel(this, alarm.id)
            }
            btnDelete.setOnClickListener {
                AlarmScheduler.cancel(this, alarm.id)
                AlarmPrefs.deleteAlarm(this, alarm.id)
                renderAlarmList()
            }
            row.setOnClickListener { showEditAlarmDialog(alarm) }

            alarmListContainer.addView(row)
        }
    }

    private fun formatDays(days: Set<Int>): String {
        if (days.isEmpty()) return "Une seule fois"
        if (days.size == 7) return "Tous les jours"
        val order = listOf(
            Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY,
            Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY
        )
        val names = mapOf(
            Calendar.MONDAY to "Lun", Calendar.TUESDAY to "Mar", Calendar.WEDNESDAY to "Mer",
            Calendar.THURSDAY to "Jeu", Calendar.FRIDAY to "Ven", Calendar.SATURDAY to "Sam",
            Calendar.SUNDAY to "Dim"
        )
        return order.filter { days.contains(it) }.joinToString(" ") { names[it] ?: "" }
    }

    // --- Ajout / édition d'une alarme -----------------------------------------------------

    private fun showAddAlarmDialog() {
        showAlarmDialog(null)
    }

    private fun showEditAlarmDialog(alarm: Alarm) {
        showAlarmDialog(alarm)
    }

    private fun showAlarmDialog(existing: Alarm?) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_add_alarm, null)
        val timePicker = view.findViewById<TimePicker>(R.id.timePicker)
        val etLabel = view.findViewById<android.widget.EditText>(R.id.etLabel)
        val dayChipsContainer = view.findViewById<LinearLayout>(R.id.dayChipsContainer)
        val tvDialogLevelName = view.findViewById<TextView>(R.id.tvDialogLevelName)
        val tvDialogLevelDesc = view.findViewById<TextView>(R.id.tvDialogLevelDesc)
        val seekDialogLevel = view.findViewById<SeekBar>(R.id.seekDialogLevel)

        timePicker.setIs24HourView(true)
        val initialHour = existing?.hour ?: Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val initialMinute = existing?.minute ?: Calendar.getInstance().get(Calendar.MINUTE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            timePicker.hour = initialHour
            timePicker.minute = initialMinute
        } else {
            @Suppress("DEPRECATION")
            timePicker.currentHour = initialHour
            @Suppress("DEPRECATION")
            timePicker.currentMinute = initialMinute
        }

        etLabel.setText(existing?.label ?: "")

        val selectedDays = (existing?.days ?: emptySet()).toMutableSet()
        val dayCalendarValues = listOf(
            Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY,
            Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY
        )
        dayChipsContainer.removeAllViews()
        val dayViews = mutableListOf<TextView>()
        for ((index, calDay) in dayCalendarValues.withIndex()) {
            val tv = TextView(this)
            tv.text = dayLabels[index]
            tv.gravity = android.view.Gravity.CENTER
            tv.setTextColor(ContextCompat.getColor(this, R.color.text_primary))
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            params.marginEnd = 6
            tv.layoutParams = params
            tv.setPadding(0, 24, 0, 24)
            tv.background = ContextCompat.getDrawable(
                this, if (selectedDays.contains(calDay)) R.drawable.bg_chip_selected else R.drawable.bg_chip
            )
            tv.setOnClickListener {
                if (selectedDays.contains(calDay)) {
                    selectedDays.remove(calDay)
                    tv.background = ContextCompat.getDrawable(this, R.drawable.bg_chip)
                } else {
                    selectedDays.add(calDay)
                    tv.background = ContextCompat.getDrawable(this, R.drawable.bg_chip_selected)
                }
            }
            dayViews.add(tv)
            dayChipsContainer.addView(tv)
        }

        val initialLevel = existing?.level ?: AlarmPrefs.defaultLevel(this)
        seekDialogLevel.progress = initialLevel
        fun updateDialogLevelTexts(progress: Int) {
            val lvl = AnnoyanceLevel.fromOrdinal(progress)
            tvDialogLevelName.text = lvl.displayName
            tvDialogLevelDesc.text = lvl.description
        }
        updateDialogLevelTexts(initialLevel)
        seekDialogLevel.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateDialogLevelTexts(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        val dialogTitle = if (existing == null) "Nouvelle alarme" else "Modifier l'alarme"
        val builder = AlertDialog.Builder(this)
            .setTitle(dialogTitle)
            .setView(view)
            .setPositiveButton("Enregistrer", null)
            .setNegativeButton("Annuler", null)

        if (existing != null) {
            builder.setNeutralButton("Supprimer") { _, _ ->
                AlarmScheduler.cancel(this, existing.id)
                AlarmPrefs.deleteAlarm(this, existing.id)
                renderAlarmList()
            }
        }

        val dialog = builder.create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val hour = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) timePicker.hour
                else @Suppress("DEPRECATION") timePicker.currentHour
                val minute = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) timePicker.minute
                else @Suppress("DEPRECATION") timePicker.currentMinute
                val label = etLabel.text.toString().trim()
                val level = seekDialogLevel.progress

                val alarm = existing?.copy(
                    hour = hour, minute = minute, label = label,
                    days = selectedDays.toSet(), level = level, enabled = true
                ) ?: Alarm(
                    id = AlarmPrefs.nextId(this),
                    hour = hour, minute = minute, label = label,
                    days = selectedDays.toSet(), enabled = true, level = level
                )

                if (existing == null) AlarmPrefs.addAlarm(this, alarm)
                else AlarmPrefs.updateAlarm(this, alarm)

                AlarmScheduler.schedule(this, alarm)
                renderAlarmList()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    // --- Test immédiat ---------------------------------------------------------------------

    private fun launchTestAlarm() {
        val level = AlarmPrefs.defaultLevel(this)
        val testAlarm = Alarm(
            id = AlarmPrefs.TEST_ALARM_ID,
            hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY),
            minute = Calendar.getInstance().get(Calendar.MINUTE),
            label = "Test",
            days = emptySet(),
            enabled = true,
            level = level
        )
        AlarmPrefs.transientTestAlarm = testAlarm
        AlarmService.start(this, AlarmPrefs.TEST_ALARM_ID)
    }
}
