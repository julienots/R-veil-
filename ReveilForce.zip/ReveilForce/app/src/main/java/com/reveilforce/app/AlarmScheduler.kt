package com.reveilforce.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

/**
 * Planifie les alarmes avec AlarmManager.setAlarmClock(), le seul mécanisme
 * garanti de sonner à l'heure exacte même en veille profonde (Doze) : c'est
 * l'API réservée aux vraies applications de réveil, pas besoin de permission
 * "alarmes exactes" supplémentaire.
 */
object AlarmScheduler {

    private fun pendingIntent(context: Context, alarmId: Int): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra(EXTRA_ALARM_ID, alarmId)
        }
        return PendingIntent.getBroadcast(
            context, alarmId, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun showIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
        return PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    /** Calcule le prochain déclenchement (aujourd'hui ou jour de répétition suivant). */
    fun nextTriggerMillis(alarm: Alarm): Long {
        val now = Calendar.getInstance()
        val candidate = Calendar.getInstance()
        candidate.set(Calendar.HOUR_OF_DAY, alarm.hour)
        candidate.set(Calendar.MINUTE, alarm.minute)
        candidate.set(Calendar.SECOND, 0)
        candidate.set(Calendar.MILLISECOND, 0)

        if (alarm.days.isEmpty()) {
            if (candidate.timeInMillis <= now.timeInMillis) {
                candidate.add(Calendar.DAY_OF_YEAR, 1)
            }
            return candidate.timeInMillis
        }

        for (i in 0..7) {
            val check = candidate.clone() as Calendar
            check.add(Calendar.DAY_OF_YEAR, i)
            val dow = check.get(Calendar.DAY_OF_WEEK)
            if (alarm.days.contains(dow) && check.timeInMillis > now.timeInMillis) {
                return check.timeInMillis
            }
        }
        candidate.add(Calendar.DAY_OF_YEAR, 7)
        return candidate.timeInMillis
    }

    fun schedule(context: Context, alarm: Alarm) {
        if (!alarm.enabled) {
            cancel(context, alarm.id)
            return
        }
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerAt = nextTriggerMillis(alarm)
        try {
            am.setAlarmClock(
                AlarmManager.AlarmClockInfo(triggerAt, showIntent(context)),
                pendingIntent(context, alarm.id)
            )
        } catch (e: Exception) {
            // Best-effort : si la planification échoue on ignore silencieusement.
        }
    }

    fun cancel(context: Context, alarmId: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context, alarmId))
    }

    /** Reprogramme une alarme répétitive après qu'elle ait sonné ; désactive les alarmes ponctuelles. */
    fun rescheduleAfterFiring(context: Context, alarm: Alarm) {
        if (alarm.days.isEmpty()) {
            alarm.enabled = false
            AlarmPrefs.updateAlarm(context, alarm)
        } else {
            schedule(context, alarm)
        }
    }

    fun scheduleAllEnabled(context: Context) {
        AlarmPrefs.getAlarms(context).filter { it.enabled }.forEach { schedule(context, it) }
    }

    const val EXTRA_ALARM_ID = "extra_alarm_id"
}
