package com.reveilforce.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * Service au premier plan qui fait vraiment sonner l'alarme :
 * - joue le son en boucle sur le flux ALARM (contourne le mode silencieux/vibreur)
 * - fait monter le volume progressivement (ou direct au max en niveau Extrême)
 * - vibre en continu
 * - garde le CPU éveillé tant que le défi n'est pas résolu
 * S'arrête uniquement via [stopRinging], appelé depuis AlarmActivity une fois
 * tous les défis validés (ou après un snooze autorisé).
 */
class AlarmService : Service() {

    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var audioManager: AudioManager? = null
    private val handler = Handler(Looper.getMainLooper())
    private var rampRunnable: Runnable? = null
    private var previousAlarmVolume = -1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val alarmId = intent?.getIntExtra(AlarmScheduler.EXTRA_ALARM_ID, -1) ?: -1
        val alarm = if (alarmId != -1) AlarmPrefs.getAlarmById(this, alarmId) else null
        val label = alarm?.label ?: ""
        val level = AnnoyanceLevel.fromOrdinal(alarm?.level ?: 1)

        startForeground(
            NotificationHelper.NOTIF_ALARM_ID,
            NotificationHelper.buildAlarmNotification(this, alarmId, label)
        )

        acquireWakeLock()
        startSound(level)
        startVibration()

        return START_STICKY
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK, "ReveilForce:AlarmWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire(20 * 60 * 1000L) // sécurité : 20 min max même en cas de bug
        }
    }

    private fun startSound(level: AnnoyanceLevel) {
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val am = audioManager ?: return
        val maxAlarmVolume = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
        previousAlarmVolume = am.getStreamVolume(AudioManager.STREAM_ALARM)

        // Niveau de départ : plus le niveau de chiant est élevé, plus on démarre fort.
        val startFraction = when (level) {
            AnnoyanceLevel.FACILE -> 0.35
            AnnoyanceLevel.MODERE -> 0.5
            AnnoyanceLevel.DIFFICILE -> 0.7
            AnnoyanceLevel.CAUCHEMAR -> 0.85
            AnnoyanceLevel.EXTREME -> 1.0
        }
        var currentVolume = (maxAlarmVolume * startFraction).toInt().coerceIn(1, maxAlarmVolume)
        am.setStreamVolume(AudioManager.STREAM_ALARM, currentVolume, 0)

        try {
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                val afd = resources.openRawResourceFd(R.raw.alarm_siren)
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            // Lecture best-effort : si le son échoue, la vibration prend le relais.
        }

        // Montée progressive du volume jusqu'au max, sur la durée définie par le niveau.
        val rampSteps = 10
        val rampIntervalMs = (level.volumeRampSeconds * 1000L / rampSteps).coerceAtLeast(200L)
        val volumeStep = ((maxAlarmVolume - currentVolume).toDouble() / rampSteps)
        var stepsDone = 0
        rampRunnable = object : Runnable {
            override fun run() {
                if (stepsDone >= rampSteps) return
                stepsDone++
                currentVolume = (currentVolume + volumeStep).toInt().coerceAtMost(maxAlarmVolume)
                am.setStreamVolume(AudioManager.STREAM_ALARM, currentVolume, 0)
                handler.postDelayed(this, rampIntervalMs)
            }
        }
        handler.postDelayed(rampRunnable!!, rampIntervalMs)
    }

    private fun startVibration() {
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        val pattern = longArrayOf(0, 600, 300, 600, 300)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }
    }

    private fun stopEverything() {
        rampRunnable?.let { handler.removeCallbacks(it) }
        rampRunnable = null

        try {
            mediaPlayer?.stop()
        } catch (e: Exception) { /* déjà arrêté */ }
        mediaPlayer?.release()
        mediaPlayer = null

        vibrator?.cancel()
        vibrator = null

        if (previousAlarmVolume >= 0) {
            try {
                audioManager?.setStreamVolume(AudioManager.STREAM_ALARM, previousAlarmVolume, 0)
            } catch (e: Exception) { /* ignore */ }
        }

        if (wakeLock?.isHeld == true) wakeLock?.release()
        wakeLock = null

        NotificationHelper.dismiss(this)
    }

    override fun onDestroy() {
        stopEverything()
        super.onDestroy()
    }

    companion object {
        fun start(context: Context, alarmId: Int) {
            val intent = Intent(context, AlarmService::class.java).apply {
                putExtra(AlarmScheduler.EXTRA_ALARM_ID, alarmId)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopRinging(context: Context) {
            context.stopService(Intent(context, AlarmService::class.java))
        }
    }
}
