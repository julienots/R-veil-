package com.reveilforce.app

import kotlin.random.Random

/** Génère le contenu des défis (calculs, phrases) selon le niveau de difficulté. */
object ChallengeManager {

    data class MathProblem(val question: String, val answer: Int)

    private val sentences = listOf(
        "Je me lève maintenant sans traîner",
        "Aujourd'hui je ne me rendors pas",
        "Le réveil a gagné, je me lève",
        "Je choisis de commencer ma journée",
        "Pas de bouton snooze pour moi aujourd'hui",
        "Mon lit peut attendre ce soir",
        "Je suis debout et je le reste"
    )

    fun randomMathProblem(level: AnnoyanceLevel): MathProblem {
        return when (level) {
            AnnoyanceLevel.FACILE, AnnoyanceLevel.MODERE -> {
                val a = Random.nextInt(2, 20)
                val b = Random.nextInt(2, 20)
                if (Random.nextBoolean()) {
                    MathProblem("$a + $b = ?", a + b)
                } else {
                    val (big, small) = if (a >= b) a to b else b to a
                    MathProblem("$big - $small = ?", big - small)
                }
            }
            AnnoyanceLevel.DIFFICILE -> {
                val a = Random.nextInt(3, 15)
                val b = Random.nextInt(3, 12)
                MathProblem("$a × $b = ?", a * b)
            }
            AnnoyanceLevel.CAUCHEMAR, AnnoyanceLevel.EXTREME -> {
                val a = Random.nextInt(4, 18)
                val b = Random.nextInt(4, 15)
                val c = Random.nextInt(2, 10)
                MathProblem("$a × $b + $c = ?", a * b + c)
            }
        }
    }

    fun randomSentence(): String = sentences.random()

    /** Nombre de secousses requises pour valider un défi SHAKE selon le niveau. */
    fun shakeTarget(level: AnnoyanceLevel): Int = when (level) {
        AnnoyanceLevel.FACILE, AnnoyanceLevel.MODERE -> 10
        AnnoyanceLevel.DIFFICILE -> 20
        AnnoyanceLevel.CAUCHEMAR -> 30
        AnnoyanceLevel.EXTREME -> 45
    }
}
