package com.reveilforce.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

/**
 * Notification plein écran qui déclenche AlarmActivity par-dessus l'écran
 * verrouillé. Le son de l'alarme n'est PAS géré par le canal de notification :
 * il est joué manuellement par AlarmService pour pouvoir contrôler la boucle
 * et la montée en volume.
 */
object NotificationHelper {

    const val CHANNEL_ALARM = "reveil_force_alarm"
    const val NOTIF_ALARM_ID = 2001

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ALARM, "Alarme", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notification plein écran qui déclenche le réveil"
            setSound(null, null) // le son est géré par AlarmService
            enableVibration(false) // la vibration est aussi gérée par AlarmService
            setBypassDnd(true)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(channel)
    }

    fun buildAlarmNotification(context: Context, alarmId: Int, label: String): Notification {
        ensureChannel(context)

        val fullScreenIntent = Intent(context, AlarmActivity::class.java).apply {
            putExtra(AlarmScheduler.EXTRA_ALARM_ID, alarmId)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            context, alarmId, fullScreenIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(context, CHANNEL_ALARM)
            .setContentTitle("Réveil !")
            .setContentText(label.ifBlank { "Il est l'heure de te lever." })
            .setSmallIcon(R.drawable.ic_stat_alarm)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(fullScreenPendingIntent)
            .setOngoing(true)
            .setAutoCancel(false)
            .build()
    }

    fun dismiss(context: Context) {
        context.getSystemService(NotificationManager::class.java).cancel(NOTIF_ALARM_ID)
    }
}
