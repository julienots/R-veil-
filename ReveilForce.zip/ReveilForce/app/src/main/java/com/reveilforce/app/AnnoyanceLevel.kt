package com.reveilforce.app

/**
 * Les 5 niveaux de "chiant" du réveil. Chaque niveau définit :
 * - la liste ordonnée des défis à enchaîner pour couper l'alarme
 * - si le snooze est autorisé
 * - la durée (en secondes) avant que le volume atteigne le maximum
 */
enum class AnnoyanceLevel(
    val displayName: String,
    val description: String,
    val challenges: List<ChallengeType>,
    val snoozeAllowed: Boolean,
    val volumeRampSeconds: Int
) {
    FACILE(
        "Facile",
        "Maintiens un bouton 3 secondes. Snooze illimité.",
        listOf(ChallengeType.HOLD_BUTTON),
        snoozeAllowed = true,
        volumeRampSeconds = 20
    ),
    MODERE(
        "Modéré",
        "3 calculs à résoudre. Snooze possible 1 fois.",
        listOf(ChallengeType.MATH, ChallengeType.MATH, ChallengeType.MATH),
        snoozeAllowed = true,
        volumeRampSeconds = 15
    ),
    DIFFICILE(
        "Difficile",
        "Secoue le téléphone puis résous 3 calculs. Pas de snooze.",
        listOf(ChallengeType.SHAKE, ChallengeType.MATH, ChallengeType.MATH, ChallengeType.MATH),
        snoozeAllowed = false,
        volumeRampSeconds = 10
    ),
    CAUCHEMAR(
        "Cauchemar",
        "Secoue fort, 4 calculs corsés, puis recopie une phrase exacte. Pas de snooze.",
        listOf(
            ChallengeType.SHAKE, ChallengeType.MATH, ChallengeType.MATH,
            ChallengeType.MATH, ChallengeType.MATH, ChallengeType.TYPE_SENTENCE
        ),
        snoozeAllowed = false,
        volumeRampSeconds = 6
    ),
    EXTREME(
        "Extrême",
        "Tout à fond : secousses intenses, 6 calculs difficiles et 2 phrases à recopier. Volume au max direct.",
        listOf(
            ChallengeType.SHAKE, ChallengeType.MATH, ChallengeType.MATH, ChallengeType.MATH,
            ChallengeType.MATH, ChallengeType.MATH, ChallengeType.MATH,
            ChallengeType.TYPE_SENTENCE, ChallengeType.SHAKE, ChallengeType.TYPE_SENTENCE
        ),
        snoozeAllowed = false,
        volumeRampSeconds = 2
    );

    companion object {
        fun fromOrdinal(i: Int): AnnoyanceLevel = entries.getOrElse(i) { MODERE }
    }
}

enum class ChallengeType {
    HOLD_BUTTON,
    MATH,
    SHAKE,
    TYPE_SENTENCE
}
