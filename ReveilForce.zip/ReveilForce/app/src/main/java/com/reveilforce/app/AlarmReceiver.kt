package com.reveilforce.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Reçu à l'heure exacte de l'alarme. Démarre immédiatement le service
 * (son + vibration + notification plein écran) puis reprogramme l'occurrence
 * suivante si l'alarme est répétitive.
 */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getIntExtra(AlarmScheduler.EXTRA_ALARM_ID, -1)
        if (alarmId == -1) return
        val alarm = AlarmPrefs.getAlarmById(context, alarmId) ?: return
        if (!alarm.enabled) return

        AlarmService.start(context, alarm.id)
        AlarmScheduler.rescheduleAfterFiring(context, alarm)
    }
}
