# Règles ProGuard par défaut (minifyEnabled = false pour l'instant)
